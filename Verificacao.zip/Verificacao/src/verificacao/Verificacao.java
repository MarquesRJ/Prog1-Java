/*
 * Trabalho 5 - Faça um programa que receba do usuario nome, sexo, estadocivil, idade e salario, e 
exiba ao fim, entretanto o sistema deve verificar se o nome tem menos de 3 letras, sexo só pode 
ser digitado m ou f, estado civil pode ser apenas s, c, v ou d, idade tem que estar entre 0 e 120 e 
salario não pode ser menor que zero.
 */
package verificacao;

import java.util.Scanner;

/**
 * E-mail: gabrielmarques142@gmail.com
 * @author Aluno Gabriel Marques
 */
public class Verificacao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // 
        String nome;
        int idade, salario = 0;

        Scanner sc = new Scanner(System.in);

        //Entrada de Dados
        System.out.println("Digite o seu nome: ");
        nome = sc.next();
        int nomel = nome.length();

        
        
        do {
        System.out.println("Digite a sua idade: ");
        idade = sc.nextInt();
        
        } while (idade < 0 || idade > 120);
        
        System.out.println("Digite o seu sexo: (m) para masculino || (f) para feminino");
        char sexo = sc.next().charAt(0);

        System.out.println("Digite o seu estado civil:   ('s' para Solteiro, 'c' para Casado, 'v' para Viúvo e 'd' para Divorciado)");
        char estadocivil = sc.next().charAt(0);

        //Condicao
        while (salario < 1) {
            System.out.println("Digite o seu salário: ");
            salario = sc.nextInt();
        }
        //Saída das Informacoes
        if (nomel > 3) {
            System.out.println("Seu nome é: " + nome + " e possui mais de 3 letras. " + nomel + " no total.");
        } else {
            System.out.println("Seu nome é: " + nome + " e possui menos de 3 letras. " + nomel + " no total.");
        }
        System.out.println("Atualmente a sua idade é: " + idade);
        System.out.println("Seu Gênero é: " + sexo);
        System.out.println("Atualmente o seu Estado Civil é: " + estadocivil);
        System.out.println("Atualmente o seu salário é: " + salario + " R$");
    }
}
