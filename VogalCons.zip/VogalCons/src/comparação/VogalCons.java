/* Trabalho 3 - Faça um programa que determine se uma letra digitada pelo usuário é uma vogal ou uma consoante. */
package comparação;

//Importacao do scanner.
import java.util.Scanner;

/**
 * E-mail: gabrielmarques142@gmail.com
 *
 * @author Aluno: Gabriel Marques
 */
public class VogalCons {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite uma letra");
        char letra = sc.next().charAt(0);

        //Condicao
        if (letra == 'a' || letra == 'e' || letra == 'i' || letra == 'o' || letra == 'u') {
            System.out.println("A letra '"+letra+"' é uma vogal");
        } else if
            (letra == 'b' || letra == 'c' || letra == 'd' || letra == 'f' || letra == 'g' || letra == 'h' || letra == 'j' || letra == 'k' || letra == 'l' || letra == 'm' || letra == 'n' || letra == 'p' || letra == 'q' || letra == 'r' || letra == 's' || letra == 't' || letra == 'v' || letra == 'x' || letra == 'y' || letra == 'z' ) {
                        System.out.println("A letra '"+letra+"' é uma consoante");

        } else { 
            System.out.println("O caracter não é uma letra");
        }
    }
}
