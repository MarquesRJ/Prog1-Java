/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package av1av2av3;

import java.util.Scanner;

/**
  *@author: Gabriel Marques
 * E-mail: gabrielmarques142@gmail.com
 */
public class av1av2av3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaração de variáveis
        float n1, n2, n3, maior;
        String nome;
        
//Inicialização do scanner
        Scanner sc = new Scanner (System.in);

        System.out.println("Por favor, digite o seu nome");
        nome = sc.next();
        
        System.out.println("Agora digite a sua primeira nota");
        n1 = sc.nextFloat();
        System.out.println("A segunda nota");
        n2 = sc.nextFloat();
        System.out.println("E por fim a sua terceita nota");
        n3 = sc.nextFloat();
        
        if (n1 > n2) { 
            maior = n1;
            System.out.println("A sua maior nota é "+maior +", "+nome);
        } else {
                    maior = n2;
                    System.out.println("A sua maior nota é "+maior+", "+nome); 
                    }
            if (n3 > maior) {
                System.out.println("A sua maior nota é "+ n3+", "+nome);
            }
        }
        
    }
