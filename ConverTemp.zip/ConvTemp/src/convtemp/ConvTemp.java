/*
 * Trabalho 1 - Faça um conversor de temperatura de Farenheit para celsius ((ºF - 32) x 5/9 = ºC) e de 
 * celsius para Farenheit ((ºc x 1.8) + 32 = ºF), o usuario deve escolher qual conversão ele quer fazer.
 */
package convtemp;

import java.util.Scanner;

/**
 * e-mail: gabrielmarques142@gmail.com
 * @author Aluno Gabriel Marques
 */
public class ConvTemp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double faren, cels;
        int opcao;
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Você deseja converter Farenheit para Celsius? Se sim digite (1) se não digite (2) e a conversão será de Celsius para Farenheit.");
        opcao = sc.nextInt();
        
        switch (opcao){
            case 1:
                System.out.println("Digite os graus em Farenheit");
                faren = sc.nextDouble();
                cels = (faren - 32 ) * 5 / 9 ;
                 System.out.println("O resultado é: "+cels);
                 break;
            case 2:
                System.out.println("Digite os graus em Celsius");
                cels = sc.nextDouble();
                faren = (cels * 1.8 ) + 32;
                System.out.println("O resultado é: "+faren);
           
        }
    }
}