/*
 *Trabalho 4 - Faça um programa que gere uma tabuada, de um valor selecionado pelo usuario.
 */
package tabuada;

import java.util.Scanner;

/**
 * E-mail: gabrielmarques142@gmail.com
 * @author Aluno Gabriel Marques
 */
public class Tabuada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaracao de variaveis
        int tabuada;
        Scanner sc = new Scanner(System.in);
        System.out.println("Digite o valor um valor para que seja gerada a tabuada:");
        tabuada = sc.nextInt();
        System.out.println("Tabuada de "+ tabuada +":");
        for (int i = 1; i < 11; i++) {
            System.out.println(tabuada+" x "+ i +" = " + (tabuada * i));
        }
        System.out.println("Bons Estudos! ;)");
        
        
   
    }
    
    
    
    }
        
    
