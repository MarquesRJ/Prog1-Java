/* Trabalho 6 - Faça um programa para contar o numero de pares e impares numa senquencia digitada pelo usuario. */
package paresimpares;

import java.util.Scanner;

/**
 * E-mail: gabrielmarques142@gmail.com
 * @author Aluno Gabriel Marques
 */
public class ParesImpares {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        int num, resto, contp = 0, cont = 0;
        Scanner sc = new Scanner(System.in);
       
        do {
            System.out.println("Digite um número: ");
            num = sc.nextInt();
            resto = num % 2;
            if (resto == 0) {
                contp++;
            } else {
                cont++;
            }

            System.out.println("Você digitou o numero: " + num);
            System.out.println("Numero de pares digitados até agora: " + contp);
            System.out.println("Numero de impares digitados até agora: " + cont);
        } while (num>0);

    }
}
