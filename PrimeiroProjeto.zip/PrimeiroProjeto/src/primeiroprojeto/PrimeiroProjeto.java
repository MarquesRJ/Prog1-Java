package PrimeiroProjeto;

/*MOSTRAR A CONDIÇÃO E MEDIA DO ALUNO E CASO O ALUNO ESTEJA COM MEDIA INFERIOR A 6, 
ELE DEVE COLOCAR A NOTA DA AV3 E REFAZER A MEDIA COM A MAIOR NOTA ENTRE A AV1 E AV2.
 */
import java.util.Scanner;

/**
 * @author aluno Gabriel Marques
 * @email: gabrielmarques142@gmail.com
 */
public class PrimeiroProjeto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declaração de variaveis 
        {

            float av1, av2, av3, media;
//Inicializaçao Scanner
            String nome;
            Scanner sc = new Scanner(System.in);
//Digitar o nome!
            System.out.println("Qual o seu nome?");
            nome = sc.next();
//Colocar Av1 e Av2 para o usuario digitar!
            System.out.println("Digite a sua primeira nota");
            av1 = sc.nextFloat();
            System.out.println("Digite a sua segunda nota");
            av2 = sc.nextFloat();

            media = (av1 + av2) / 2;

            if (media >= 6) {
                System.out.println("Você Passou com media " + media + ", " +nome);
            } else {
                if (av1 > av2) {
                    System.out.println("Digite a sua terceira nota");
                    av3 = sc.nextFloat();
                    media = (av1 + av3) / 2;
                }
                 {
                    if (media >= 6) {
                        System.out.println("Você passou com media " + media + ", " +nome);
                    } else { System.out.println ("Reprovado");}
                }
            }
        }

    }

}
