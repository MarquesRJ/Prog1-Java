/*
Trabalho nº2 - Faça um programa que compare dois numeros digitados pelo usuario e diga qual é o maior.
 */
package nummaior;

import java.util.Scanner;

/**
 * E-mail: gabrielmarques142@gmail.com
 * @author Aluno Gabriel Marques
 */
public class NumMaior {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Declaracao de variaveis
        float num1, num2;
        Scanner sc = new Scanner(System.in);
    
        System.out.println("Digite um número");
        num1 = sc.nextFloat();
        System.out.println("Digite outro número");
        num2 = sc.nextFloat();
        
        if (num1>num2) {
            System.out.println("O número "+num1+" é maior que o número "+num2);
        } else {
            System.out.println("O número "+num2+" é maior que o número "+num1);
        }
    
    
    }
    
    
}
